package com.example.sessionfour.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.example.sessionfour.repository.EmployeeRepository;
import com.example.sessionfour.repository.SkillRepository;
import com.example.sessionfour.exceptions.RecordNotFoundException;
import com.example.sessionfour.models.Employee;
import com.example.sessionfour.models.Skill;
import com.example.sessionfour.models.CreateSkillRequest;

@Service
public class EmployeeService {
	@Autowired
	private EmployeeRepository repository;
	@Autowired
	private SkillRepository skillRepository;
	
	public Page<Employee> get(Pageable pageRequest) {
		return repository.findAll(pageRequest);
	}
	
	public Employee get(Long id) throws RecordNotFoundException {
		Optional<Employee> employee = repository.findById(id);
		
		if (employee.isPresent()) {
			return employee.get();
		} else {
			throw new RecordNotFoundException("Employee not found.");
		}
	}
	
	public Employee create(Employee employee) {
		return repository.save(employee);
	}
	
	public Employee update(Long id, Employee employee) throws RecordNotFoundException {
		Optional<Employee> existingEmployee = repository.findById(id);
		
		if (existingEmployee.isPresent()) {
			Employee a = existingEmployee.get();
			a.setName(employee.getName());
			
			return repository.save(a);
		} else {
			throw new RecordNotFoundException("Employee not found.");
		}
	}
	
	public void delete(Long id) throws RecordNotFoundException {
		Optional<Employee> employee = repository.findById(id);
		
		if (employee.isPresent()) {
			repository.deleteById(id);
		} else {
			throw new RecordNotFoundException("Employee not found.");
		}
	}
	
	public Page<Skill> getSkills(Long id, Pageable pageRequest) throws RecordNotFoundException {
		return skillRepository.findAllByEmployeeId(id, pageRequest);
	}
	
	public Skill createSkill(Long employeeId, CreateSkillRequest request) throws RecordNotFoundException {
		Optional<Employee> employeeRecord = repository.findById(employeeId);
		if (!employeeRecord.isPresent()) {
			throw new RecordNotFoundException("Employee not found.");
		}
		Employee employee = employeeRecord.get();
		
		Skill skill = new Skill();
		skill.setLastUsed(request.getLastUsed());
		skill.setDescription(request.getDescription());
		skill.setEmployeeId(employeeId);
		skill = skillRepository.save(skill);
		
		List<Skill> skills = employee.getSkills();
		if (skills == null) {
			skills = new ArrayList<Skill>();
		}
		skills.add(skill);
		employee.setSkills(skills);
		
		employee = repository.save(employee);
		return skill;
	}
}
